#include "game.h"
int main()
{

    Game g;
    g.start_game();
    return 0;
}
